Refresh Meter
1) افتح المجلد في Android Studio (Koala أو أحدث) ودع Gradle يعمل Sync.
2) ثبّت Shizuku على الجهاز وشغّله (Wireless debugging أو root).
3) شغّل التطبيق > امنح إذن Shizuku > (اختياري) شغّل المؤشر العائم.
