package com.example.refreshmeter;

interface IShellService {
    // رقم المعاملة 16777114 مطلوب من Shizuku لدالة التدمير
    void destroy() = 16777114;
    String exec(String cmd) = 1;
}
