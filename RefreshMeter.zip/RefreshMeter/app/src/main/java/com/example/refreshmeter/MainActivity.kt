package com.example.refreshmeter

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.max

class MainActivity : ComponentActivity() {

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        RefreshMonitor.init(this)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { MainScreen() }
            }
        }
    }

    override fun onResume() { super.onResume(); RefreshMonitor.startAppFps(); RefreshMonitor.refreshState() }
    override fun onPause() { RefreshMonitor.stopAppFps(); super.onPause() }
}

@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val status by RefreshMonitor.status.collectAsState()
    val sys by RefreshMonitor.systemHz.collectAsState()
    val disp by RefreshMonitor.displayHz.collectAsState()
    val live by RefreshMonitor.liveFps.collectAsState()
    val target by RefreshMonitor.liveTarget.collectAsState()
    val hist by RefreshMonitor.history.collectAsState()
    val overlayOn by OverlayService.running.collectAsState()

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("قياس معدل تحديث الشاشة", style = MaterialTheme.typography.titleLarge)

        // الرقم الكبير
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("%.0f".format(sys ?: disp), fontSize = 72.sp, color = MaterialTheme.colorScheme.primary)
                Text("Hz", fontSize = 20.sp)
                Text(
                    if (sys != null) "المصدر: النظام (Shizuku)" else "المصدر: واجهة Display (تقريبي)",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        // ثلاث قراءات
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("النظام", sys?.let { "%.1f".format(it) } ?: "--", Modifier.weight(1f))
            Stat("Display", "%.1f".format(disp), Modifier.weight(1f))
            Stat("FPS فعلي", live?.let { "%.0f".format(it) } ?: "--", Modifier.weight(1f))
        }

        if (target.isNotEmpty()) Text("التطبيق الأمامي: $target", style = MaterialTheme.typography.bodySmall)

        // الرسم البياني
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("آخر 60 ثانية (الخط السميك: FPS فعلي، الرفيع: Hz)", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                RateChart(hist, Modifier.fillMaxWidth().height(180.dp))
            }
        }

        // حالة Shizuku
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    when (status) {
                        ShizukuStatus.NOT_RUNNING -> "Shizuku غير مفعّل. شغّله أولاً (عبر Wireless debugging أو root)."
                        ShizukuStatus.NO_PERMISSION -> "Shizuku يعمل لكن التطبيق بلا إذن."
                        ShizukuStatus.CONNECTING -> "جارٍ الاتصال بخدمة shell..."
                        ShizukuStatus.CONNECTED -> "متصل بـ Shizuku ✔"
                    }
                )
                when (status) {
                    ShizukuStatus.NOT_RUNNING -> Button(onClick = {
                        ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                            ?.let { ctx.startActivity(it) }
                    }) { Text("فتح تطبيق Shizuku") }
                    ShizukuStatus.NO_PERMISSION -> Button(onClick = { RefreshMonitor.requestPermission() }) {
                        Text("منح الإذن")
                    }
                    else -> {}
                }
                if (status == ShizukuStatus.CONNECTED && sys == null)
                    Text(
                        "تعذّر تحليل خرج dumpsys على جهازك. عدّل قائمة probes في RefreshMonitor.kt.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
            }
        }

        // المؤشر العائم
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                when {
                    overlayOn -> OverlayService.stop(ctx)
                    Settings.canDrawOverlays(ctx) -> OverlayService.start(ctx)
                    else -> ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }
        ) { Text(if (overlayOn) "إيقاف المؤشر العائم" else "تشغيل المؤشر العائم") }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RateChart(data: List<Pair<Float, Float>>, modifier: Modifier) {
    val fpsColor = MaterialTheme.colorScheme.primary
    val hzColor = MaterialTheme.colorScheme.tertiary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    Canvas(modifier) {
        val peak = data.maxOfOrNull { max(it.first, if (it.second.isNaN()) 0f else it.second) } ?: 60f
        val top = max(60f, ceil(peak * 1.15f / 30f) * 30f)
        for (i in 0..4) {
            val y = size.height * i / 4f
            drawLine(grid, Offset(0f, y), Offset(size.width, y), 1f)
        }
        if (data.size < 2) return@Canvas
        val stepX = size.width / 59f
        fun yOf(v: Float) = size.height * (1f - v / top)
        fun xOf(i: Int) = size.width - (data.size - 1 - i) * stepX

        val hz = Path()
        data.forEachIndexed { i, p ->
            val x = xOf(i)
            if (i == 0) hz.moveTo(x, yOf(p.first)) else {
                hz.lineTo(x, yOf(data[i - 1].first))
                hz.lineTo(x, yOf(p.first))
            }
        }
        drawPath(hz, hzColor, style = Stroke(width = 3f))

        val fp = Path()
        var started = false
        data.forEachIndexed { i, p ->
            if (p.second.isNaN()) { started = false } else {
                val x = xOf(i)
                if (!started) { fp.moveTo(x, yOf(p.second)); started = true } else fp.lineTo(x, yOf(p.second))
            }
        }
        drawPath(fp, fpsColor, style = Stroke(width = 5f))
    }
}
