package com.example.refreshmeter

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

enum class ShizukuStatus { NOT_RUNNING, NO_PERMISSION, CONNECTING, CONNECTED }

object RefreshMonitor {

    // معدل التحديث الفعلي للنظام (يحتاج Shizuku)
    val systemHz = MutableStateFlow<Float?>(null)
    // معدل الوضع الحالي حسب واجهة Display العامة
    val displayHz = MutableStateFlow(0f)
    // معدل ticks الفعلية لـ Choreographer داخل التطبيق
    val appFps = MutableStateFlow(0f)
    // آخر 120 قراءة (~60 ثانية)
    val history = MutableStateFlow<List<Float>>(emptyList())
    val status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)

    private const val REQ_CODE = 1001
    private lateinit var app: Context
    private var inited = false
    private var service: IShellService? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private fun rx(r: Regex): (String) -> Float? =
        { out -> r.find(out)?.groupValues?.get(1)?.toFloatOrNull() }

    // يقرأ "mode N" ثم يبحث عن fps الخاص بالوضع N (صيغة Android 12-14 مثل Nord 2)
    private fun parseActiveMode(out: String): Float? {
        val ov = Regex("""refreshRateOverride\s+([0-9.]+)""").find(out)
            ?.groupValues?.get(1)?.toFloatOrNull()
        if (ov != null && ov > 0f) return ov
        val id = Regex(""",\s*mode\s+(\d+),""").find(out)?.groupValues?.get(1) ?: return null
        return Regex("""\{id=$id,[^}]*?fps=([0-9.]+)""").find(out)
            ?.groupValues?.get(1)?.toFloatOrNull()
    }

    // أوامر بديلة لأن صيغة dumpsys تختلف بين الأجهزة والإصدارات
    private val probes: List<Pair<String, (String) -> Float?>> = listOf(
        "dumpsys display | grep -m1 'mBaseDisplayInfo=DisplayInfo'" to ::parseActiveMode,
        "dumpsys display | grep -m1 -o 'renderFrameRate [0-9.]*'" to rx(Regex("""renderFrameRate\s+([0-9.]+)""")),
        "dumpsys SurfaceFlinger | grep -m1 -i 'refresh-rate'" to rx(Regex("""([0-9]+(?:\.[0-9]+)?)\s*Hz""", RegexOption.IGNORE_CASE)),
        "dumpsys display | grep -m1 -o 'mRefreshRate=[0-9.]*'" to rx(Regex("""mRefreshRate=([0-9.]+)"""))
    )
    private var workingProbe = -1

    private val conn = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                service = IShellService.Stub.asInterface(binder)
                status.value = ShizukuStatus.CONNECTED
            }
        }
        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            if (Shizuku.pingBinder()) refreshState() else status.value = ShizukuStatus.NOT_RUNNING
        }
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refreshState() }
        Shizuku.addBinderDeadListener {
            service = null
            status.value = ShizukuStatus.NOT_RUNNING
        }
        Shizuku.addRequestPermissionResultListener { _, _ -> refreshState() }
        refreshState()
        startPolling()
    }

    fun refreshState() {
        if (!Shizuku.pingBinder()) { status.value = ShizukuStatus.NOT_RUNNING; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            status.value = ShizukuStatus.NO_PERMISSION; return
        }
        if (service != null) { status.value = ShizukuStatus.CONNECTED; return }
        status.value = ShizukuStatus.CONNECTING
        val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG)
            .version(1)
        Shizuku.bindUserService(args, conn)
    }

    fun requestPermission() {
        if (Shizuku.pingBinder()) Shizuku.requestPermission(REQ_CODE)
    }

    private fun startPolling() = scope.launch {
        val dm = app.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        while (true) {
            val d = dm.getDisplay(0)?.refreshRate ?: 0f
            displayHz.value = d
            val sys = readSystemHz()
            systemHz.value = sys
            val v = sys ?: d
            if (v > 0f) history.update { (it + v).takeLast(120) }
            delay(500)
        }
    }

    private fun readSystemHz(): Float? {
        val s = service ?: return null
        val order = if (workingProbe >= 0) listOf(workingProbe) else probes.indices.toList()
        for (i in order) {
            val out = try { s.exec(probes[i].first) } catch (e: Exception) { "" }
            val v = probes[i].second(out)
            if (v != null && v > 0f) { workingProbe = i; return v }
        }
        workingProbe = -1
        return null
    }

    // ---- قياس Choreographer (على الـ main thread) ----
    private val main = Handler(Looper.getMainLooper())
    private var running = false
    private var frames = 0
    private var winStart = 0L

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!running) return
            if (winStart == 0L) { winStart = ns; frames = 0 } else {
                frames++
                val dt = ns - winStart
                if (dt >= 500_000_000L) {
                    appFps.value = frames * 1_000_000_000f / dt
                    frames = 0; winStart = ns
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun startAppFps() {
        main.post {
            if (running) return@post
            running = true; winStart = 0L; frames = 0
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
    }

    fun stopAppFps() {
        main.post { running = false }
    }
}
