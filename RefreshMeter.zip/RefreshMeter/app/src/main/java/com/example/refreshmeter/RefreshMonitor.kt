package com.example.refreshmeter

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

enum class ShizukuStatus { NOT_RUNNING, NO_PERMISSION, CONNECTING, CONNECTED }

object RefreshMonitor {

    // تردد الشاشة المفعّل (يحتاج Shizuku)
    val systemHz = MutableStateFlow<Float?>(null)
    // تردد الوضع الحالي حسب واجهة Display العامة
    val displayHz = MutableStateFlow(0f)
    // نبضات Choreographer داخل نافذة هذا التطبيق (vsync وليس إطارات مرسومة)
    val appFps = MutableStateFlow(0f)
    // الإطارات الفعلية التي عرضها النظام للتطبيق الأمامي (SurfaceFlinger)
    val liveFps = MutableStateFlow<Float?>(null)
    val liveTarget = MutableStateFlow("")
    // آخر 60 ثانية: (Hz, FPS أو NaN)
    val history = MutableStateFlow<List<Pair<Float, Float>>>(emptyList())
    val status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)

    private const val REQ_CODE = 1001
    private lateinit var app: Context
    private var inited = false
    private var service: IShellService? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private fun rx(r: Regex): (String) -> Float? =
        { out -> r.find(out)?.groupValues?.get(1)?.toFloatOrNull() }

    // يقرأ "mode N" ثم يبحث عن fps الخاص بالوضع N
    private fun parseActiveMode(out: String): Float? {
        val ov = Regex("""refreshRateOverride\s+([0-9.]+)""").find(out)
            ?.groupValues?.get(1)?.toFloatOrNull()
        if (ov != null && ov > 0f) return ov
        val id = Regex(""",\s*mode\s+(\d+),""").find(out)?.groupValues?.get(1) ?: return null
        return Regex("""\{id=$id,[^}]*?fps=([0-9.]+)""").find(out)
            ?.groupValues?.get(1)?.toFloatOrNull()
    }

    private val probes: List<Pair<String, (String) -> Float?>> = listOf(
        "dumpsys display | grep -m1 'mBaseDisplayInfo=DisplayInfo'" to ::parseActiveMode,
        "dumpsys display | grep -m1 -o 'renderFrameRate [0-9.]*'" to rx(Regex("""renderFrameRate\s+([0-9.]+)""")),
        "dumpsys SurfaceFlinger | grep -m1 -i 'refresh-rate'" to rx(Regex("""([0-9]+(?:\.[0-9]+)?)\s*Hz""", RegexOption.IGNORE_CASE)),
        "dumpsys display | grep -m1 -o 'mRefreshRate=[0-9.]*'" to rx(Regex("""mRefreshRate=([0-9.]+)"""))
    )
    private var workingProbe = -1

    private val conn = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                service = IShellService.Stub.asInterface(binder)
                status.value = ShizukuStatus.CONNECTED
            }
        }
        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            if (Shizuku.pingBinder()) refreshState() else status.value = ShizukuStatus.NOT_RUNNING
        }
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refreshState() }
        Shizuku.addBinderDeadListener {
            service = null
            status.value = ShizukuStatus.NOT_RUNNING
        }
        Shizuku.addRequestPermissionResultListener { _, _ -> refreshState() }
        refreshState()
        startHzLoop()
        startFpsLoop()
    }

    fun refreshState() {
        if (!Shizuku.pingBinder()) { status.value = ShizukuStatus.NOT_RUNNING; return }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            status.value = ShizukuStatus.NO_PERMISSION; return
        }
        if (service != null) { status.value = ShizukuStatus.CONNECTED; return }
        status.value = ShizukuStatus.CONNECTING
        val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG)
            .version(1)
        Shizuku.bindUserService(args, conn)
    }

    fun requestPermission() {
        if (Shizuku.pingBinder()) Shizuku.requestPermission(REQ_CODE)
    }

    // ---------- تردد الشاشة ----------
    private fun startHzLoop() = scope.launch {
        val dm = app.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        while (true) {
            displayHz.value = dm.getDisplay(0)?.refreshRate ?: 0f
            systemHz.value = readSystemHz()
            delay(500)
        }
    }

    private fun readSystemHz(): Float? {
        val s = service ?: return null
        val order = if (workingProbe >= 0) listOf(workingProbe) else probes.indices.toList()
        for (i in order) {
            val out = try { s.exec(probes[i].first) } catch (e: Exception) { "" }
            val v = probes[i].second(out)
            if (v != null && v > 0f) { workingProbe = i; return v }
        }
        workingProbe = -1
        return null
    }

    // ---------- FPS الفعلي للتطبيق الأمامي ----------
    private var cachedPkg = ""
    private var cachedLayers: List<String> = emptyList()

    private fun focusedPackage(s: IShellService): String? {
        val out = s.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        return Regex("""([A-Za-z0-9_.]+)/""").find(out)?.groupValues?.get(1)
    }

    private fun findLayers(s: IShellService, pkg: String): List<String> {
        val out = s.exec("dumpsys SurfaceFlinger --list | grep -F '$pkg'")
        return out.lines().map { it.trim() }.filter {
            it.isNotEmpty() && !it.startsWith("Bounds for") && !it.startsWith("Background for")
        }.take(4)
    }

    // يحسب FPS من أوقات العرض الفعلية (العمود الثاني) لآخر ثانية
    private fun layerFps(s: IShellService, layer: String): Float {
        val q = layer.replace("'", "'\\''")
        val out = s.exec("dumpsys SurfaceFlinger --latency '$q'")
        val ts = ArrayList<Long>()
        out.lineSequence().drop(1).forEach { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 3) {
                val t = p[1].toLongOrNull()
                if (t != null && t > 0L && t != Long.MAX_VALUE) ts.add(t)
            }
        }
        if (ts.size < 2) return 0f
        ts.sort()
        val tmax = ts.last()
        // الشاشة ثابتة: لا إطارات جديدة منذ أكثر من 0.8 ثانية
        if (System.nanoTime() - tmax > 800_000_000L) return 0f
        val win = ts.filter { it > tmax - 1_000_000_000L }
        if (win.size < 2) return 0f
        val fps = (win.size - 1) * 1_000_000_000f / (win.last() - win.first())
        return fps.coerceAtMost(240f)
    }

    private fun startFpsLoop() = scope.launch {
        while (true) {
            val s = service
            var fps: Float? = null
            if (s != null) {
                try {
                    val pkg = focusedPackage(s)
                    if (pkg != null) {
                        liveTarget.value = pkg
                        if (pkg != cachedPkg || cachedLayers.isEmpty()) {
                            cachedLayers = findLayers(s, pkg); cachedPkg = pkg
                        }
                        fps = cachedLayers.map { layerFps(s, it) }.maxOrNull()
                        // أعد البحث عن الطبقات في الدورة القادمة إن لم نجد إطارات
                        if (fps == null || fps == 0f) cachedLayers = emptyList()
                    }
                } catch (e: Exception) { }
            }
            liveFps.value = fps
            val hz = systemHz.value ?: displayHz.value
            history.update { (it + (hz to (fps ?: Float.NaN))).takeLast(60) }
            delay(1000)
        }
    }

    // ---------- قياس Choreographer (على الـ main thread) ----------
    private val main = Handler(Looper.getMainLooper())
    private var running = false
    private var frames = 0
    private var winStart = 0L

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!running) return
            if (winStart == 0L) { winStart = ns; frames = 0 } else {
                frames++
                val dt = ns - winStart
                if (dt >= 500_000_000L) {
                    appFps.value = frames * 1_000_000_000f / dt
                    frames = 0; winStart = ns
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun startAppFps() {
        main.post {
            if (running) return@post
            running = true; winStart = 0L; frames = 0
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
    }

    fun stopAppFps() {
        main.post { running = false }
    }
}
