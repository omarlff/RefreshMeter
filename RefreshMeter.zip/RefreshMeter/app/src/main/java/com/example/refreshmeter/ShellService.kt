package com.example.refreshmeter

import kotlin.system.exitProcess

/** يعمل داخل عملية منفصلة بصلاحيات shell (adb) عبر Shizuku. */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        ""
    }
}
